package com.o3interactive.ijawnation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
